export default{

    database:{
        user:'TEST',
        password: '1234',
        connectString: '172.17.0.2/ORCL18'
    }
}